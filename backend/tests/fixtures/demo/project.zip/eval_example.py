eval(input())
